import React from 'react';
import { View, Text, Pressable, StyleSheet } from 'react-native';
import { useRouter } from 'expo-router';

export default function HomeScreen() {
  const router = useRouter();
  return <View style={s.page}>
    <Text style={s.crown}>♛</Text>
    <Text style={s.title}>DURAK ONLINE</Text>
    <Text style={s.subtitle}>36 КАРТ · 2 ИГРОКА</Text>
    <Pressable style={s.primary} onPress={() => router.push('/game')}>
      <Text style={s.primaryText}>ИГРАТЬ</Text>
    </Pressable>
    <Pressable style={s.secondary} onPress={() => router.push('/game')}>
      <Text style={s.secondaryText}>СОЗДАТЬ КОМНАТУ</Text>
    </Pressable>
    <Pressable style={s.secondary} onPress={() => router.push('/game')}>
      <Text style={s.secondaryText}>ВОЙТИ ПО КОДУ</Text>
    </Pressable>
    <Text style={s.note}>Демонстрационная версия · Онлайн-комнаты будут добавлены отдельно</Text>
  </View>;
}
const s = StyleSheet.create({
  page:{flex:1,backgroundColor:'#073D2B',alignItems:'center',justifyContent:'center',padding:24},
  crown:{fontSize:54,color:'#E8E4DA'},
  title:{fontSize:30,fontWeight:'900',letterSpacing:2,color:'#F4F0E7',marginTop:10},
  subtitle:{color:'#BFCFC4',letterSpacing:2,marginTop:8,marginBottom:42},
  primary:{width:'100%',padding:18,borderRadius:14,backgroundColor:'#E7E3D9',marginBottom:12},
  primaryText:{textAlign:'center',fontWeight:'900',color:'#172638',fontSize:16},
  secondary:{width:'100%',padding:17,borderRadius:14,borderWidth:1,borderColor:'#C5D2C8',marginBottom:12},
  secondaryText:{textAlign:'center',fontWeight:'800',color:'#F4F0E7'},
  note:{color:'#9EB4A5',fontSize:11,textAlign:'center',marginTop:22}
});

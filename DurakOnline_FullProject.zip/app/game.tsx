import React,{useMemo,useState} from 'react';
import {SafeAreaView,ScrollView,StyleSheet,Text,View,Pressable} from 'react-native';
import PlayingCard from '../src/components/PlayingCard';
import {Card,createDeck,dealSix,shuffleDeck} from '../src/game/deck';
export default function GameScreen(){
 const initial=useMemo(()=>dealSix(shuffleDeck(createDeck())),[]);
 const [hand,setHand]=useState<Card[]>(initial.player);
 const [selected,setSelected]=useState<string|null>(null);
 const [tableCard,setTableCard]=useState<Card|null>(null);
 const [stock,setStock]=useState<Card[]>(initial.stock);
 function play(){if(!selected||tableCard)return;const c=hand.find(x=>x.id===selected);if(!c)return;setTableCard(c);setHand(old=>old.filter(x=>x.id!==selected));setSelected(null);}
 function take(){if(!tableCard)return;setHand(old=>[...old,tableCard]);setTableCard(null);}
 function restart(){const d=dealSix(shuffleDeck(createDeck()));setHand(d.player);setStock(d.stock);setTableCard(null);setSelected(null);}
 return <SafeAreaView style={s.page}>
  <View style={s.header}><Text style={s.title}>DURAK ONLINE</Text><Text style={s.sub}>Демонстрация карт · 36 карт</Text></View>
  <View style={s.opponent}><Text style={s.label}>Соперник · 6 карт</Text><ScrollView horizontal>{Array.from({length:6}).map((_,i)=><View key={i} style={{marginRight:-24}}><PlayingCard faceDown width={58}/></View>)}</ScrollView></View>
  <View style={s.table}><Text style={s.label}>Игровой стол</Text>{tableCard?<PlayingCard card={tableCard} width={88}/>:<Text style={s.hint}>Выбери карту и нажми «На стол»</Text>}<Text style={s.stock}>В колоде: {stock.length} карт</Text></View>
  <View style={s.actions}><Pressable style={s.primary} onPress={play}><Text style={s.primaryText}>НА СТОЛ</Text></Pressable><Pressable style={s.secondary} onPress={take}><Text style={s.secondaryText}>ЗАБРАТЬ</Text></Pressable><Pressable style={s.secondary} onPress={restart}><Text style={s.secondaryText}>НОВАЯ РАЗДАЧА</Text></Pressable></View>
  <View style={s.handBlock}><Text style={s.label}>Твои карты · {hand.length}</Text><ScrollView horizontal contentContainerStyle={s.hand}>{hand.map(c=><View key={c.id} style={{marginRight:8}}><PlayingCard card={c} selected={selected===c.id} onPress={()=>setSelected(selected===c.id?null:c.id)} width={76}/></View>)}</ScrollView></View>
 </SafeAreaView>;
}
const s=StyleSheet.create({
 page:{flex:1,backgroundColor:'#073D2B',paddingHorizontal:14},header:{alignItems:'center',paddingVertical:14},
 title:{color:'#F1EEE6',fontSize:22,fontWeight:'900',letterSpacing:2},sub:{color:'#B9C8BE',marginTop:4,fontSize:12},
 opponent:{minHeight:130,paddingTop:8},table:{flex:1,minHeight:190,borderWidth:1,borderColor:'#47735D',borderRadius:16,alignItems:'center',justifyContent:'center',padding:12},
 label:{color:'#DDE7DF',fontSize:13,fontWeight:'700',marginBottom:10},hint:{color:'#B9C8BE',textAlign:'center'},stock:{color:'#C8D5CB',fontSize:12,marginTop:10},
 actions:{flexDirection:'row',flexWrap:'wrap',gap:8,justifyContent:'center',paddingVertical:12},
 primary:{backgroundColor:'#E7E3D9',borderRadius:10,paddingHorizontal:18,paddingVertical:12},primaryText:{color:'#172638',fontWeight:'900',fontSize:12},
 secondary:{borderWidth:1,borderColor:'#C5D2C8',borderRadius:10,paddingHorizontal:12,paddingVertical:12},secondaryText:{color:'#F1EEE6',fontWeight:'800',fontSize:11},
 handBlock:{minHeight:180,paddingTop:8,paddingBottom:12},hand:{alignItems:'flex-end',paddingTop:14,paddingBottom:8}
});

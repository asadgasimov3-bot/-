export type Suit = 'spades' | 'hearts' | 'diamonds' | 'clubs';
export type Rank = '6' | '7' | '8' | '9' | '10' | 'J' | 'Q' | 'K' | 'A';
export type Card = { id: string; suit: Suit; rank: Rank };
export const SUITS: Suit[] = ['spades', 'hearts', 'diamonds', 'clubs'];
export const RANKS: Rank[] = ['6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'];
export const SUIT_SYMBOL: Record<Suit, string> = {
  spades: '♠', hearts: '♥', diamonds: '♦', clubs: '♣'
};
export function createDeck(): Card[] {
  return SUITS.flatMap(suit => RANKS.map(rank => ({id:`${rank}-${suit}`,suit,rank})));
}
export function shuffleDeck(cards: Card[]): Card[] {
  const deck=[...cards];
  for(let i=deck.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[deck[i],deck[j]]=[deck[j],deck[i]];}
  return deck;
}
export function dealSix(cards=shuffleDeck(createDeck())) {
  return {player:cards.slice(0,6),opponent:cards.slice(6,12),stock:cards.slice(12),trump:cards[cards.length-1]};
}

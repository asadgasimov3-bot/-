import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Card, SUIT_SYMBOL } from '../game/deck';
type Props={card?:Card;faceDown?:boolean;selected?:boolean;onPress?:()=>void;width?:number};
export default function PlayingCard({card,faceDown=false,selected=false,onPress,width=76}:Props){
 const height=width*1.43;
 if(faceDown||!card)return <View style={[s.back,{width,height},selected&&s.selected]}><View style={s.backInner}><Text style={s.backMark}>✥</Text><Text style={s.backSmall}>DURAK</Text><Text style={s.backMark}>✥</Text></View></View>;
 const red=card.suit==='hearts'||card.suit==='diamonds', ink=red?'#B52B35':'#18212D', sym=SUIT_SYMBOL[card.suit], face=['J','Q','K'].includes(card.rank);
 return <Pressable onPress={onPress} style={[s.card,{width,height},selected&&s.selected]}>
  <View style={s.corner}><Text style={[s.rank,{color:ink}]}>{card.rank}</Text><Text style={[s.suit,{color:ink}]}>{sym}</Text></View>
  {face?<View style={s.face}><Text style={[s.faceRank,{color:ink}]}>{card.rank}</Text><View style={[s.line,{backgroundColor:ink}]}/><Text style={[s.faceSuit,{color:ink}]}>{sym}</Text></View>
  :<View style={s.pips}><Text style={[s.big,{color:ink}]}>{sym}</Text><Text style={[s.small,{color:ink}]}>{card.rank}</Text></View>}
  <View style={[s.corner,s.bottom]}><Text style={[s.rank,{color:ink}]}>{card.rank}</Text><Text style={[s.suit,{color:ink}]}>{sym}</Text></View>
 </Pressable>;
}
const s=StyleSheet.create({
 card:{backgroundColor:'#F7F3E9',borderRadius:10,borderWidth:1,borderColor:'#D8D0C2',padding:6,justifyContent:'space-between',elevation:4},
 selected:{transform:[{translateY:-12}],borderColor:'#72C5A0',borderWidth:2},
 corner:{alignSelf:'flex-start',alignItems:'center'},bottom:{alignSelf:'flex-end',transform:[{rotate:'180deg'}]},
 rank:{fontSize:17,lineHeight:18,fontWeight:'800'},suit:{fontSize:14,lineHeight:15},
 pips:{flex:1,alignItems:'center',justifyContent:'center'},big:{fontSize:44},small:{fontSize:11,opacity:.65},
 face:{flex:1,alignItems:'center',justifyContent:'center',marginVertical:2,borderWidth:1,borderColor:'#D9D1C4',borderRadius:5,backgroundColor:'#F0EBDD'},
 faceRank:{fontSize:30,fontWeight:'900'},line:{height:2,width:'65%',marginVertical:3,opacity:.55},faceSuit:{fontSize:25},
 back:{backgroundColor:'#142D48',borderRadius:10,padding:5,borderWidth:1,borderColor:'#D5DCE4',elevation:4},
 backInner:{flex:1,borderWidth:1,borderColor:'#AAB8C8',borderRadius:6,alignItems:'center',justifyContent:'space-evenly',backgroundColor:'#1C3B5B'},
 backMark:{color:'#D9E0E8',fontSize:24},backSmall:{color:'#E4E9EF',fontSize:8,letterSpacing:2,fontWeight:'800'}
});
